import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  
  console.log("LOOK HERE");
  console.log('event:', event);
  console.log('event.body:', event.body);
  console.warn("JSON HERE", JSON.parse(event.body));
  
  const payload = JSON.parse(event.body);
  
  console.log('email:', payload.email);
  console.log('webpage: ', payload.webpage);
  
  console.log("AND HERE");

  
  // Get the current date in ISO format
  const date = new Date().toISOString();
  const email = payload.email;
  const webpage = payload.webpage;
  
  // Define the item to be inserted into the DynamoDB table
  const command = new PutCommand({
    TableName: "book-signups",
    Item: {
      email,
      webpage,
      date
    },
  });
  
  console.log('params:', command);
  
  // Insert the item into the DynamoDB table
  try {
    const response = await docClient.send(command);
   console.log(response);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Signed up successfully.' })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: `{"message":"Error inserting email into DynamoDB signups table. Error: ${error.message.replace(/"/g, '\\"')}"}`,
    };
  }
};
